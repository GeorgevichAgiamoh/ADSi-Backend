# ADSI Backend

## Info
Company: Stable Shield Solutions
Developer: Daniel, Remote fullstack developer
Technology: PHP, Laravel, MySQL

### Progress Update

> Setting up authentication REST API (DONE)

> User data upload endpoint (DONE)

> Testing (DONE)

> Provisioning admin (DONE)

> Building more endpoints (DONE)

> Sending Mails (DONE) 

> Optimizing ( 40% )

> Messaging (...)
